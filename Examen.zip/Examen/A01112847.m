function A01112847

%% Secci�n 1
warning off
clear all
close all

I = imread('protesis1.jpg');
IG = rgb2gray(I);
Max = max(max(IG));

S = 255 - Max;

I_B = IG + S;

C = 255/222;

I_C = C*IG;

figure,
subplot(2,2,1), imshow(I), title('Imagen Original');
subplot(2,2,2), imshow(IG), title('Imagen en escala de grises');
subplot(2,2,3), imshow(I_B), title('Imagen con brillo');
subplot(2,2,4), imshow(I_C), title('Imagen con constraste');

%% Seccion 2
warning off
clear all
close all

I = imread('protesis1.jpg');
IG = rgb2gray(I);
IGS = imnoise(IG,'salt & pepper',0.0002);
[m , n] = size(IGS);

canvas = zeros(m , n);
arr = zeros(1,8);
a = 1;
b = 1;
p = 1;

for i = 2: m-1
    for j = 2: n-1
        for s = -a: a
            for t = -b:b
                if(s ~= 0 && t ~= 0)
                    arr(p) = IGS(i+s,j+t);
                    p = p + 1;
                    
                end
            end
        end
        p = 1;
        
        if(IGS(i,j) > max(arr))
            canvas(i,j) = max(arr);
            
        elseif (IGS(i,j) < min(arr))
            canvas(i,j) = min(arr);
            
        else
            canvas(i,j) = IGS(i,j);
            
        end
        
        
    end
end

figure,
subplot(1,2,1), imshow(IGS), title('Imagen con ruido');
subplot(1,2,2), imshow(uint8(canvas)), title('Imagen filtrada');

%% Secci�n 3
warning off
clear all
close all

I = imread('protesis1.jpg');
IG = rgb2gray(I);

IG_a = imadjust(IG, [0.1 0.9], [0 1], 3);
IG_a = IG_a*1.5;

K = fspecial('Gaussian');

IF = imfilter(IG_a, K)*1.1;
p = imhist(IF);
y_eq = histeq(IF,p);


BW = im2bw(y_eq,.75);

IG_sola = (BW.*im2double(IG));
x = 2;
y = 3;

figure,
subplot(x,y,1), imshow(IG), title('Imagen original en escala de grises'),
subplot(x,y,2), imshow(IG_a), title('Imagen con ajuste de brillo contraste')
subplot(x,y,3), imshow(IF), title('Imagen Filtrada'),
subplot(x,y,4), imshow(BW), title('Binarizaci�n'),
subplot(x,y,6), imshow(IG_sola), title('Imagen original con la pr�tesis aislada');

%% Seccion 4
close all
clear all
warning off
clc

Queen = imread('reina.jpg');
Queen_g = rgb2gray(Queen);

Queen_res = imresize(Queen_g, [100, 100]);

canvas = zeros(800);

for i = 1:800
    for j = 1:800
        if(mod(i,200) == 0 && mod(j,200) == 0);
            canvas(i-100:i, j-100:j) = 1;
            
        end
    end
end

canvasr = imrotate(canvas, 180);

Tablero = uint8(imcomplement(canvas + canvasr)*255);
Tablero(300:500, 1:800) = Tablero(300:500, 1:800) + 85;

% Posici�n 2,3
Tablero(201:300, 101:200) = Queen_res(:,:);

% Posici�n 3,5
Tablero(301:400, 501:600) = imcomplement(Queen_res(:,:))+Tablero(301:400, 501:600) ;

% Posici�n 8,8
Tablero(701:800, 701:800) = imcomplement(Queen_res(:,:));

figure,
imshow(Tablero), title('Ajedrez');


end