function Coocurrencia
%% NumLevels
clear all
close all
clc

n = 8;

%% Ladrillos

I1 = imread('ladrillo1.jpg');
I2 = imread('ladrillo3.jpg');

IG1 = rgb2gray(I1);
IG2 = rgb2gray(I2);

figure,
subplot(4,3,1), imshow(IG1), title('Imagen ladrillos1')
subplot(4,3,4), imhist(IG1), title('Histograma ladrillos1');
subplot(4,3,7), imshow(IG2), title('Imagen ladrillos2')
subplot(4,3,10), imhist(IG2), title('HIstograma ladrillos2');

Media1 = mean(mean(IG1));
Media2 = mean(mean(IG2));

Varianza1 = var(var(double(IG1)));
Varianza2 = var(var(double(IG2)));

GrayCo1 = graycomatrix(IG1, 'NumLevels', n);
GrayCo2 = graycomatrix(IG2, 'NumLevels', n);

%% Madera

I3 = imread('madera1.jpg');
I4 = imread('madera2.jpg');

IG3 = rgb2gray(I3);
IG4 = rgb2gray(I4);

% figure,
% subplot(1,2,1),imhist(IG3), title('Imagen 1');
% subplot(1,2,2), imhist(IG4), title('Imegen 2');

subplot(4,3,2), imshow(IG3), title('Imagen madera1')
subplot(4,3,5), imhist(IG3), title('Histograma madera1');
subplot(4,3,8), imshow(IG4), title('Imagen madera2')
subplot(4,3,11), imhist(IG4), title('HIstograma madera2');

Media3 = mean(mean(IG3));
Media4 = mean(mean(IG4));

Varianza3 = var(var(double(IG3)));
Varianza4 = var(var(double(IG4)));

GrayCo3 = graycomatrix(IG3, 'NumLevels', n);
GrayCo4 = graycomatrix(IG4, 'NumLevels', n);

%% Suelo

I5 = imread('Suelo1.jpg');
I6 = imread('Suelo2.jpg');

IG5 = rgb2gray(I5);
IG6 = rgb2gray(I6);

% figure,
% subplot(1,2,1),imhist(IG5), title('Imagen 1');
% subplot(1,2,2), imhist(IG6), title('Imegen 2');

subplot(4,3,3), imshow(IG5), title('Imagen Suelo1')
subplot(4,3,6), imhist(IG5), title('Histograma Suelo1');
subplot(4,3,9), imshow(IG6), title('Imagen Suelo2')
subplot(4,3,12), imhist(IG6), title('HIstograma Suelo2');

Media5 = mean(mean(IG5));
Media6 = mean(mean(IG6));

Varianza5 = var(var(double(IG5)));
Varianza6 = var(var(double(IG6)));

GrayCo5 = graycomatrix(IG5, 'NumLevels', n);
GrayCo6 = graycomatrix(IG6, 'NumLevels', n);

%% Propiedades de coocurrencia

% addpath('C:\Users\Usuario\Desktop\8vo Semestre\Procesamiento de Imagen\C�digos\Clase\line efficientLBP');

stats1 = graycoprops(GrayCo1, {'Energy', 'contrast', 'Homogeneity'});
brillo1 = mean(mean(GrayCo1));
entropy1 = 1/stats1.Homogeneity;
features1 = extractLBPFeatures(IG1);
imFeatures1 = efficientLBP(IG1);

stats2 = graycoprops(GrayCo2, {'Energy', 'contrast', 'Homogeneity'});
brillo2 = mean(mean(GrayCo2));
entropy2 = 1/stats2.Homogeneity;
features2 = extractLBPFeatures(IG2);
imFeatures2 = efficientLBP(IG2);

stats3= graycoprops(GrayCo3, {'Energy', 'contrast', 'Homogeneity'});
brillo3 = mean(mean(GrayCo3));
entropy3 = 1/stats3.Homogeneity;
features3 = extractLBPFeatures(IG3);
imFeatures3 = efficientLBP(IG3);

stats4 = graycoprops(GrayCo4, {'Energy', 'contrast', 'Homogeneity'});
brillo4 = mean(mean(GrayCo4));
entropy4 = 1/stats4.Homogeneity;
features4 = extractLBPFeatures(IG4);
imFeatures4 = efficientLBP(IG4);

stats5 = graycoprops(GrayCo5, {'Energy', 'contrast', 'Homogeneity'});
brillo5 = mean(mean(GrayCo5));
entropy5 = 1/stats5.Homogeneity;
features5 = extractLBPFeatures(IG5);
imFeatures5 = efficientLBP(IG5);

stats6 = graycoprops(GrayCo6, {'Energy', 'contrast', 'Homogeneity'});
brillo6 = mean(mean(GrayCo6));
entropy6 = 1/stats6.Homogeneity;
features6 = extractLBPFeatures(IG6);
imFeatures6 = efficientLBP(IG6);

figure,
subplot(2,3,1), imshow(imFeatures1), title('1');
subplot(2,3,2), imshow(imFeatures2), title('2');
subplot(2,3,3), imshow(imFeatures3), title('3');
subplot(2,3,4), imshow(imFeatures4), title('4');
subplot(2,3,5), imshow(imFeatures5), title('5');
subplot(2,3,6), imshow(imFeatures6), title('6');

end